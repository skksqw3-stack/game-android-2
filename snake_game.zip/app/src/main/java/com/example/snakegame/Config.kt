package com.example.snakegame

/** حالت‌های سختی */
class Difficulty(val speed: Float, val walls: Boolean, val cols: Int, val rows: Int)

/** تم‌های رنگی */
class Theme(
    val bg: Int, val grid: Int, val head: Int,
    val body: Int, val food: Int, val text: Int
)

data class Cell(val x: Int, val y: Int)

val DIFFICULTIES: LinkedHashMap<String, Difficulty> = linkedMapOf(
    "Easy" to Difficulty(0.22f, false, 15, 20),
    "Medium" to Difficulty(0.15f, true, 18, 24),
    "Hard" to Difficulty(0.09f, true, 22, 30),
    "Free" to Difficulty(0.14f, false, 18, 24)
)

val THEMES: LinkedHashMap<String, Theme> = linkedMapOf(
    "Night" to Theme(
        rgbf(0.08f, 0.09f, 0.14f), rgbf(0.13f, 0.15f, 0.22f), rgbf(0.25f, 1f, 0.45f),
        rgbf(0.1f, 0.75f, 0.25f), rgbf(1f, 0.25f, 0.35f), rgbf(1f, 1f, 1f)
    ),
    "Neon" to Theme(
        rgbf(0.02f, 0f, 0.08f), rgbf(0.1f, 0f, 0.2f), rgbf(0f, 1f, 1f),
        rgbf(0f, 0.55f, 1f), rgbf(1f, 0f, 0.8f), rgbf(0.8f, 1f, 1f)
    ),
    "Forest" to Theme(
        rgbf(0.12f, 0.18f, 0.1f), rgbf(0.18f, 0.25f, 0.15f), rgbf(0.9f, 0.95f, 0.4f),
        rgbf(0.4f, 0.7f, 0.2f), rgbf(1f, 0.4f, 0.2f), rgbf(0.9f, 1f, 0.85f)
    ),
    "Fire" to Theme(
        rgbf(0.12f, 0.03f, 0.02f), rgbf(0.25f, 0.08f, 0.05f), rgbf(1f, 0.9f, 0.2f),
        rgbf(1f, 0.45f, 0.1f), rgbf(1f, 0.95f, 0.6f), rgbf(1f, 0.95f, 0.8f)
    )
)

/** حداقل فاصله‌ی کشیدن انگشت (پیکسل) برای تشخیص سوایپ */
const val SWIPE_MIN_DISTANCE = 30f
