package com.example.topdownracer

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager

class MainActivity : Activity() {

    private lateinit var racer: RacerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        racer = RacerView(this)
        setContentView(racer)
    }

    override fun onResume() {
        super.onResume()
        racer.startLoop()
    }

    override fun onPause() {
        super.onPause()
        racer.stopLoop()
    }
}
