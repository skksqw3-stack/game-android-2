package com.example.topdownracer

import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.view.View

/** رنگ با مقادیر 0..1 (مثل Kivy) */
fun rgbf(r: Float, g: Float, b: Float): Int =
    Color.rgb((r * 255f + 0.5f).toInt(), (g * 255f + 0.5f).toInt(), (b * 255f + 0.5f).toInt())

fun lighten(c: Int, amt: Int = 35): Int = Color.argb(
    Color.alpha(c),
    minOf(255, Color.red(c) + amt),
    minOf(255, Color.green(c) + amt),
    minOf(255, Color.blue(c) + amt)
)

fun darken(c: Int, amt: Int = 60): Int = Color.argb(
    Color.alpha(c),
    maxOf(0, Color.red(c) - amt),
    maxOf(0, Color.green(c) - amt),
    maxOf(0, Color.blue(c) - amt)
)

private fun shape(color: Int, radius: Float): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = radius
    return g
}

/** پس‌زمینه‌ی دکمه با حالت‌های عادی / فشرده / غیرفعال */
fun buttonBg(color: Int, radius: Float): Drawable {
    val s = StateListDrawable()
    s.addState(intArrayOf(-android.R.attr.state_enabled), shape(darken(color), radius))
    s.addState(intArrayOf(android.R.attr.state_pressed), shape(lighten(color), radius))
    s.addState(intArrayOf(), shape(color, radius))
    return s
}

@Suppress("DEPRECATION")
fun View.setBg(d: Drawable) {
    if (Build.VERSION.SDK_INT >= 16) {
        this.background = d
    } else {
        this.setBackgroundDrawable(d)
    }
}
