package com.example.whackmole

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Random

/** دکمه‌ی خانه‌ی بازی (معادل MoleButton در نسخه‌ی پایتون) */
class MoleButton(context: Context) : Button(context) {
    var isMole = false
}

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private val rnd = Random()

    private val buttons = ArrayList<MoleButton>()
    private lateinit var scoreLabel: TextView
    private lateinit var timeLabel: TextView
    private lateinit var startBtn: Button

    private var score = 0
    private var timeLeft = 30
    private var running = false
    private var currentMole: MoleButton? = null
    private var spawnInterval = 800L   // میلی‌ثانیه

    private val colorIdle = rgbf(0.2f, 0.2f, 0.3f)
    private val colorMole = rgbf(0.85f, 0.5f, 0.2f)
    private val colorStart = rgbf(0.2f, 0.7f, 0.4f)

    private val tickRunnable = object : Runnable {
        override fun run() {
            tick()
            if (running) handler.postDelayed(this, 1000L)
        }
    }

    private val spawnRunnable = object : Runnable {
        override fun run() {
            spawnMole()
            if (running) handler.postDelayed(this, spawnInterval)
        }
    }

    private fun dp(v: Float): Float = v * resources.displayMetrics.density

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val pad = dp(15f).toInt()
        val gap = dp(5f).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(rgbf(0.08f, 0.08f, 0.12f))
        root.setPadding(pad, pad, pad, pad)

        // ---- نوار بالا: امتیاز و زمان ----
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        scoreLabel = makeLabel("Score: 0")
        timeLabel = makeLabel("Time: 30")
        top.addView(scoreLabel, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f))
        top.addView(timeLabel, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f))
        val topLp = LinearLayout.LayoutParams(MATCH_PARENT, 0, 0.12f)
        topLp.setMargins(0, gap, 0, gap)
        root.addView(top, topLp)

        // ---- گرید 3x3 ----
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        for (r in 0 until 3) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (c in 0 until 3) {
                val b = MoleButton(this)
                b.textSize = 30f
                b.setTypeface(Typeface.DEFAULT_BOLD)
                b.setTextColor(Color.WHITE)
                b.minimumHeight = 0
                b.minimumWidth = 0
                b.setPadding(0, 0, 0, 0)
                setButtonColor(b, colorIdle)
                b.setOnClickListener { onTap(b) }
                buttons.add(b)
                val lp = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f)
                lp.setMargins(gap, gap, gap, gap)
                row.addView(b, lp)
            }
            grid.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        }
        val gridLp = LinearLayout.LayoutParams(MATCH_PARENT, 0, 0.78f)
        gridLp.setMargins(0, gap, 0, gap)
        root.addView(grid, gridLp)

        // ---- دکمه‌ی شروع ----
        startBtn = Button(this)
        startBtn.text = "START"
        startBtn.textSize = 20f
        startBtn.setTypeface(Typeface.DEFAULT_BOLD)
        startBtn.setTextColor(Color.WHITE)
        startBtn.minimumHeight = 0
        setButtonColor(startBtn, colorStart)
        startBtn.setOnClickListener { startGame() }
        val startLp = LinearLayout.LayoutParams(MATCH_PARENT, 0, 0.10f)
        startLp.setMargins(0, gap, 0, gap)
        root.addView(startBtn, startLp)

        setContentView(root)
    }

    private fun makeLabel(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = 20f
        t.setTextColor(Color.WHITE)
        t.gravity = Gravity.CENTER
        return t
    }

    private fun setButtonColor(b: Button, color: Int) {
        b.setBg(buttonBg(color, dp(8f)))
    }

    // ---------------- منطق بازی ----------------
    private fun startGame() {
        if (running) return
        running = true
        score = 0
        timeLeft = 30
        spawnInterval = 800L
        scoreLabel.text = "Score: 0"
        timeLabel.text = "Time: 30"
        startBtn.text = "PLAYING..."
        startBtn.isEnabled = false

        for (b in buttons) resetButton(b)
        currentMole = null

        handler.removeCallbacks(tickRunnable)
        handler.removeCallbacks(spawnRunnable)
        handler.postDelayed(tickRunnable, 1000L)
        handler.postDelayed(spawnRunnable, spawnInterval)
        spawnMole()   // اولین مول فوری
    }

    private fun tick() {
        timeLeft -= 1
        timeLabel.text = "Time: $timeLeft"
        if (timeLeft <= 0) endGame()
    }

    private fun spawnMole() {
        if (!running) return
        // مول قبلی رو پاک کن اگه زده نشده
        currentMole?.let { resetButton(it) }

        val free = ArrayList<MoleButton>()
        for (b in buttons) if (!b.isMole) free.add(b)
        if (free.isEmpty()) return

        val mole = free[rnd.nextInt(free.size)]
        mole.isMole = true
        mole.text = "HIT!"
        setButtonColor(mole, colorMole)
        currentMole = mole
    }

    private fun onTap(btn: MoleButton) {
        if (!running) return
        if (btn.isMole) {
            score += 1
            scoreLabel.text = "Score: $score"
            resetButton(btn)
            currentMole = null
            // سرعت رو کم‌کم بیشتر کن
            handler.removeCallbacks(spawnRunnable)
            spawnInterval = maxOf(350, 800 - score * 20).toLong()
            handler.postDelayed(spawnRunnable, spawnInterval)
        } else {
            // اشتباه زد → امتیاز کم
            score = maxOf(0, score - 1)
            scoreLabel.text = "Score: $score"
        }
    }

    private fun resetButton(b: MoleButton) {
        b.isMole = false
        b.text = ""
        setButtonColor(b, colorIdle)
    }

    private fun endGame() {
        running = false
        handler.removeCallbacks(tickRunnable)
        handler.removeCallbacks(spawnRunnable)
        for (b in buttons) resetButton(b)
        currentMole = null
        startBtn.text = "GAME OVER! Score: $score — TAP TO RESTART"
        startBtn.isEnabled = true
    }

    // ---------------- چرخه‌ی حیات ----------------
    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tickRunnable)
        handler.removeCallbacks(spawnRunnable)
    }

    override fun onResume() {
        super.onResume()
        if (running) {
            handler.postDelayed(tickRunnable, 1000L)
            handler.postDelayed(spawnRunnable, spawnInterval)
        }
    }
}
